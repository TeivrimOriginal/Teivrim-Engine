CMakeFiles/PolygonEditor.dir/src/Core/Render/Win32/rendererw.cpp.obj: \
 E:\SOOBSHESTVA\Game_Engine\VERSION\ 3\3\src\Core\Render\Win32\rendererw.cpp \
 E:\SOOBSHESTVA\Game_Engine\VERSION\ 3\3\src\Core\Render\Win32\rendererw.h \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/GL/glew.h \
 C:/mingw64/x86_64-w64-mingw32/include/inttypes.h \
 C:/mingw64/x86_64-w64-mingw32/include/crtdefs.h \
 C:/mingw64/x86_64-w64-mingw32/include/corecrt.h \
 C:/mingw64/x86_64-w64-mingw32/include/_mingw.h \
 C:/mingw64/x86_64-w64-mingw32/include/_mingw_mac.h \
 C:/mingw64/x86_64-w64-mingw32/include/_mingw_secapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/vadefs.h \
 C:/mingw64/x86_64-w64-mingw32/include/sdks/_mingw_ddk.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/stdint.h \
 C:/mingw64/x86_64-w64-mingw32/include/stdint.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/stddef.h \
 C:/mingw64/x86_64-w64-mingw32/include/stddef.h \
 C:/mingw64/x86_64-w64-mingw32/include/GL/glu.h \
 C:/mingw64/x86_64-w64-mingw32/include/GL/gl.h \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/glm.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/_fixes.hpp \
 C:/mingw64/include/c++/15.2.0/cmath \
 C:/mingw64/include/c++/15.2.0/bits/requires_hosted.h \
 C:/mingw64/include/c++/15.2.0/x86_64-w64-mingw32/bits/c++config.h \
 C:/mingw64/include/c++/15.2.0/x86_64-w64-mingw32/bits/os_defines.h \
 C:/mingw64/include/c++/15.2.0/x86_64-w64-mingw32/bits/cpu_defines.h \
 C:/mingw64/include/c++/15.2.0/pstl/pstl_config.h \
 C:/mingw64/include/c++/15.2.0/bits/cpp_type_traits.h \
 C:/mingw64/include/c++/15.2.0/bits/version.h \
 C:/mingw64/include/c++/15.2.0/type_traits \
 C:/mingw64/include/c++/15.2.0/ext/type_traits.h \
 C:/mingw64/x86_64-w64-mingw32/include/math.h \
 C:/mingw64/include/c++/15.2.0/bits/std_abs.h \
 C:/mingw64/x86_64-w64-mingw32/include/stdlib.h \
 C:/mingw64/x86_64-w64-mingw32/include/corecrt_wstdlib.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/limits.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/syslimits.h \
 C:/mingw64/x86_64-w64-mingw32/include/limits.h \
 C:/mingw64/x86_64-w64-mingw32/include/sec_api/stdlib_s.h \
 C:/mingw64/include/c++/15.2.0/stdlib.h \
 C:/mingw64/x86_64-w64-mingw32/include/malloc.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/mm_malloc.h \
 C:/mingw64/x86_64-w64-mingw32/include/errno.h \
 C:/mingw64/include/c++/15.2.0/bits/specfun.h \
 C:/mingw64/include/c++/15.2.0/bits/stl_algobase.h \
 C:/mingw64/include/c++/15.2.0/bits/functexcept.h \
 C:/mingw64/include/c++/15.2.0/bits/exception_defines.h \
 C:/mingw64/include/c++/15.2.0/ext/numeric_traits.h \
 C:/mingw64/include/c++/15.2.0/bits/stl_pair.h \
 C:/mingw64/include/c++/15.2.0/bits/move.h \
 C:/mingw64/include/c++/15.2.0/bits/utility.h \
 C:/mingw64/include/c++/15.2.0/bits/stl_iterator_base_types.h \
 C:/mingw64/include/c++/15.2.0/bits/stl_iterator_base_funcs.h \
 C:/mingw64/include/c++/15.2.0/bits/concept_check.h \
 C:/mingw64/include/c++/15.2.0/debug/assertions.h \
 C:/mingw64/include/c++/15.2.0/bits/stl_iterator.h \
 C:/mingw64/include/c++/15.2.0/bits/ptr_traits.h \
 C:/mingw64/include/c++/15.2.0/debug/debug.h \
 C:/mingw64/include/c++/15.2.0/bits/predefined_ops.h \
 C:/mingw64/include/c++/15.2.0/bit C:/mingw64/include/c++/15.2.0/concepts \
 C:/mingw64/include/c++/15.2.0/limits \
 C:/mingw64/include/c++/15.2.0/tr1/gamma.tcc \
 C:/mingw64/include/c++/15.2.0/tr1/special_function_util.h \
 C:/mingw64/include/c++/15.2.0/tr1/bessel_function.tcc \
 C:/mingw64/include/c++/15.2.0/tr1/beta_function.tcc \
 C:/mingw64/include/c++/15.2.0/tr1/ell_integral.tcc \
 C:/mingw64/include/c++/15.2.0/tr1/exp_integral.tcc \
 C:/mingw64/include/c++/15.2.0/tr1/hypergeometric.tcc \
 C:/mingw64/include/c++/15.2.0/tr1/legendre_function.tcc \
 C:/mingw64/include/c++/15.2.0/tr1/modified_bessel_func.tcc \
 C:/mingw64/include/c++/15.2.0/tr1/poly_hermite.tcc \
 C:/mingw64/include/c++/15.2.0/tr1/poly_laguerre.tcc \
 C:/mingw64/include/c++/15.2.0/tr1/riemann_zeta.tcc \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/setup.hpp \
 C:/mingw64/include/c++/15.2.0/cassert \
 C:/mingw64/x86_64-w64-mingw32/include/assert.h \
 C:/mingw64/include/c++/15.2.0/cstdlib \
 C:/mingw64/include/c++/15.2.0/cstddef \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/simd/platform.h \
 C:/mingw64/include/c++/15.2.0/cstdint \
 C:/mingw64/include/c++/15.2.0/climits \
 C:/mingw64/include/c++/15.2.0/cfloat \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/float.h \
 C:/mingw64/x86_64-w64-mingw32/include/float.h \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/fwd.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/qualifier.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/setup.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/vec2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_bool2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_vec2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_vec2.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/compute_vector_relational.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_bool2_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_float2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_float2_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_double2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_double2_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_int2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_int2_sized.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/scalar_int_sized.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/setup.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_uint2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_uint2_sized.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/scalar_uint_sized.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/vec3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_bool3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_vec3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_vec3.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/compute_vector_decl.hpp \
 C:/mingw64/include/c++/15.2.0/functional \
 C:/mingw64/include/c++/15.2.0/bits/stl_function.h \
 C:/mingw64/include/c++/15.2.0/backward/binders.h \
 C:/mingw64/include/c++/15.2.0/tuple \
 C:/mingw64/include/c++/15.2.0/bits/uses_allocator.h \
 C:/mingw64/include/c++/15.2.0/bits/invoke.h \
 C:/mingw64/include/c++/15.2.0/bits/functional_hash.h \
 C:/mingw64/include/c++/15.2.0/bits/hash_bytes.h \
 C:/mingw64/include/c++/15.2.0/bits/refwrap.h \
 C:/mingw64/include/c++/15.2.0/bits/std_function.h \
 C:/mingw64/include/c++/15.2.0/new \
 C:/mingw64/include/c++/15.2.0/bits/exception.h \
 C:/mingw64/include/c++/15.2.0/typeinfo \
 C:/mingw64/include/c++/15.2.0/unordered_map \
 C:/mingw64/include/c++/15.2.0/initializer_list \
 C:/mingw64/include/c++/15.2.0/bits/unordered_map.h \
 C:/mingw64/include/c++/15.2.0/bits/hashtable.h \
 C:/mingw64/include/c++/15.2.0/bits/hashtable_policy.h \
 C:/mingw64/include/c++/15.2.0/ext/aligned_buffer.h \
 C:/mingw64/include/c++/15.2.0/ext/alloc_traits.h \
 C:/mingw64/include/c++/15.2.0/bits/alloc_traits.h \
 C:/mingw64/include/c++/15.2.0/bits/stl_construct.h \
 C:/mingw64/include/c++/15.2.0/bits/memoryfwd.h \
 C:/mingw64/include/c++/15.2.0/bits/allocator.h \
 C:/mingw64/include/c++/15.2.0/x86_64-w64-mingw32/bits/c++allocator.h \
 C:/mingw64/include/c++/15.2.0/bits/new_allocator.h \
 C:/mingw64/include/c++/15.2.0/bits/enable_special_members.h \
 C:/mingw64/include/c++/15.2.0/bits/node_handle.h \
 C:/mingw64/include/c++/15.2.0/bits/range_access.h \
 C:/mingw64/include/c++/15.2.0/bits/erase_if.h \
 C:/mingw64/include/c++/15.2.0/bits/memory_resource.h \
 C:/mingw64/include/c++/15.2.0/bits/uses_allocator_args.h \
 C:/mingw64/include/c++/15.2.0/vector \
 C:/mingw64/include/c++/15.2.0/bits/stl_uninitialized.h \
 C:/mingw64/include/c++/15.2.0/bits/stl_vector.h \
 C:/mingw64/include/c++/15.2.0/bits/stl_bvector.h \
 C:/mingw64/include/c++/15.2.0/bits/vector.tcc \
 C:/mingw64/include/c++/15.2.0/array \
 C:/mingw64/include/c++/15.2.0/compare \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/_vectorize.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_bool3_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_float3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_float3_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_double3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_double3_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_int3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_int3_sized.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_uint3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_uint3_sized.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/vec4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_bool4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_vec4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_vec4.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_bool4_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_float4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_float4_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_double4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_double4_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_int4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_int4_sized.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_uint4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_uint4_sized.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/mat2x2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double2x2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat2x2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat2x2.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/matrix.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/mat2x3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double2x3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat2x3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat2x3.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double2x3_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float2x3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float2x3_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/mat2x4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double2x4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat2x4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat2x4.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double2x4_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float2x4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float2x4_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/mat3x2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double3x2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat3x2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat3x2.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double3x2_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float3x2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float3x2_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/mat3x3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double3x3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat3x3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat3x3.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/common.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/func_common.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/vector_relational.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/func_vector_relational.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/compute_common.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_vec1.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_vec1.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double3x3_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float3x3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float3x3_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/mat3x4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double3x4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat3x4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat3x4.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double3x4_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float3x4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float3x4_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/mat4x2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double4x2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat4x2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat4x2.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double4x2_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float4x2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float4x2_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/mat4x3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double4x3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat4x3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat4x3.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double4x3_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float4x3.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float4x3_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/mat4x4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double4x4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat4x4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_mat4x4.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/geometric.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/func_geometric.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/exponential.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/func_exponential.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double4x4_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float4x4.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float4x4_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/func_matrix.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_double2x2_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float2x2.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_float2x2_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/trigonometric.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/func_trigonometric.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/packing.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/func_packing.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_half.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_half.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/integer.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/func_integer.inl \
 C:/mingw64/include/c++/15.2.0/string \
 C:/mingw64/include/c++/15.2.0/bits/stringfwd.h \
 C:/mingw64/include/c++/15.2.0/bits/char_traits.h \
 C:/mingw64/include/c++/15.2.0/bits/postypes.h \
 C:/mingw64/include/c++/15.2.0/cwchar \
 C:/mingw64/x86_64-w64-mingw32/include/wchar.h \
 C:/mingw64/x86_64-w64-mingw32/include/corecrt_stdio_config.h \
 C:/mingw64/x86_64-w64-mingw32/include/corecrt_wctype.h \
 C:/mingw64/x86_64-w64-mingw32/include/_mingw_off_t.h \
 C:/mingw64/x86_64-w64-mingw32/include/_mingw_stat64.h \
 C:/mingw64/x86_64-w64-mingw32/include/swprintf.inl \
 C:/mingw64/x86_64-w64-mingw32/include/sec_api/wchar_s.h \
 C:/mingw64/include/c++/15.2.0/bits/localefwd.h \
 C:/mingw64/include/c++/15.2.0/x86_64-w64-mingw32/bits/c++locale.h \
 C:/mingw64/include/c++/15.2.0/clocale \
 C:/mingw64/x86_64-w64-mingw32/include/locale.h \
 C:/mingw64/x86_64-w64-mingw32/include/stdio.h \
 C:/mingw64/x86_64-w64-mingw32/include/sec_api/stdio_s.h \
 C:/mingw64/include/c++/15.2.0/iosfwd \
 C:/mingw64/include/c++/15.2.0/cctype \
 C:/mingw64/x86_64-w64-mingw32/include/ctype.h \
 C:/mingw64/include/c++/15.2.0/bits/ostream_insert.h \
 C:/mingw64/include/c++/15.2.0/bits/cxxabi_forced.h \
 C:/mingw64/include/c++/15.2.0/bits/basic_string.h \
 C:/mingw64/include/c++/15.2.0/string_view \
 C:/mingw64/include/c++/15.2.0/bits/string_view.tcc \
 C:/mingw64/include/c++/15.2.0/ext/string_conversions.h \
 C:/mingw64/include/c++/15.2.0/cstdio \
 C:/mingw64/include/c++/15.2.0/cerrno \
 C:/mingw64/include/c++/15.2.0/bits/charconv.h \
 C:/mingw64/include/c++/15.2.0/bits/basic_string.tcc \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/src/Core/Render/Parser/parser.h \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/src/Control/camera.h \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/gtc/matrix_transform.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_projection.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/gtc/constants.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/scalar_constants.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/scalar_constants.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/gtc/constants.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_projection.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_clip_space.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_clip_space.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_transform.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/matrix_transform.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/gtc/matrix_transform.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/src/Application/WindowAPIsupport/Win32/InitialWin32.h \
 C:/mingw64/x86_64-w64-mingw32/include/windows.h \
 C:/mingw64/x86_64-w64-mingw32/include/sdkddkver.h \
 C:/mingw64/x86_64-w64-mingw32/include/excpt.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/stdarg.h \
 C:/mingw64/x86_64-w64-mingw32/include/stdarg.h \
 C:/mingw64/x86_64-w64-mingw32/include/_mingw_stdarg.h \
 C:/mingw64/x86_64-w64-mingw32/include/windef.h \
 C:/mingw64/x86_64-w64-mingw32/include/winapifamily.h \
 C:/mingw64/x86_64-w64-mingw32/include/minwindef.h \
 C:/mingw64/x86_64-w64-mingw32/include/specstrings.h \
 C:/mingw64/x86_64-w64-mingw32/include/sal.h \
 C:/mingw64/x86_64-w64-mingw32/include/concurrencysal.h \
 C:/mingw64/x86_64-w64-mingw32/include/driverspecs.h \
 C:/mingw64/x86_64-w64-mingw32/include/winnt.h \
 C:/mingw64/x86_64-w64-mingw32/include/_mingw_unicode.h \
 C:/mingw64/x86_64-w64-mingw32/include/apiset.h \
 C:/mingw64/x86_64-w64-mingw32/include/psdk_inc/intrin-impl.h \
 C:/mingw64/x86_64-w64-mingw32/include/basetsd.h \
 C:/mingw64/x86_64-w64-mingw32/include/guiddef.h \
 C:/mingw64/x86_64-w64-mingw32/include/string.h \
 C:/mingw64/x86_64-w64-mingw32/include/sec_api/string_s.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/x86intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/x86gprintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/ia32intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/adxintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/bmiintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/bmi2intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/cetintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/cldemoteintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/clflushoptintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/clwbintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/clzerointrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/cmpccxaddintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/enqcmdintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/fxsrintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/lzcntintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/lwpintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/movdirintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/mwaitintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/mwaitxintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/pconfigintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/popcntintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/pkuintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/prfchiintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/raointintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/rdseedintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/rtmintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/serializeintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/sgxintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/tbmintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/tsxldtrkintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/uintrintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/waitpkgintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/wbnoinvdintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/xsaveintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/xsavecintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/xsaveoptintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/xsavesintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/xtestintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/hresetintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/usermsrintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/immintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/mmintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/xmmintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/emmintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/pmmintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/tmmintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/smmintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/wmmintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avxintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avxvnniintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avxifmaintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avxvnniint8intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avxvnniint16intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx2intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512fintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512cdintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vlintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512bwintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512dqintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vlbwintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vldqintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512ifmaintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512ifmavlintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vbmiintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vbmivlintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vpopcntdqintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vbmi2intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vbmi2vlintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vnniintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vnnivlintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vpopcntdqvlintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512bitalgintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512bitalgvlintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vp2intersectintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vp2intersectvlintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512fp16intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512fp16vlintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/shaintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/sm3intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/sha512intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/sm4intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/fmaintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/f16cintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/gfniintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/vaesintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/vpclmulqdqintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512bf16vlintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512bf16intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avxneconvertintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxtileintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxint8intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxbf16intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxcomplexintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxavx512intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxtf32intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxtransposeintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxfp8intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/prfchwintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/keylockerintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxfp16intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2mediaintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2-512mediaintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2convertintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2-512convertintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2bf16intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2-512bf16intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2satcvtintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2-512satcvtintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2minmaxintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2-512minmaxintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2copyintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/movrsintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxmovrsintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/mm3dnow.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/fma4intrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/ammintrin.h \
 C:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/xopintrin.h \
 C:/mingw64/x86_64-w64-mingw32/include/pshpack4.h \
 C:/mingw64/x86_64-w64-mingw32/include/poppack.h \
 C:/mingw64/x86_64-w64-mingw32/include/pshpack4.h \
 C:/mingw64/x86_64-w64-mingw32/include/pshpack2.h \
 C:/mingw64/x86_64-w64-mingw32/include/poppack.h \
 C:/mingw64/x86_64-w64-mingw32/include/pshpack2.h \
 C:/mingw64/x86_64-w64-mingw32/include/pshpack8.h \
 C:/mingw64/x86_64-w64-mingw32/include/pshpack8.h \
 C:/mingw64/x86_64-w64-mingw32/include/ktmtypes.h \
 C:/mingw64/x86_64-w64-mingw32/include/winbase.h \
 C:/mingw64/x86_64-w64-mingw32/include/apisetcconv.h \
 C:/mingw64/x86_64-w64-mingw32/include/minwinbase.h \
 C:/mingw64/x86_64-w64-mingw32/include/bemapiset.h \
 C:/mingw64/x86_64-w64-mingw32/include/debugapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/errhandlingapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/fibersapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/fileapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/handleapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/heapapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/ioapiset.h \
 C:/mingw64/x86_64-w64-mingw32/include/interlockedapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/jobapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/libloaderapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/memoryapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/namedpipeapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/namespaceapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/processenv.h \
 C:/mingw64/x86_64-w64-mingw32/include/processthreadsapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/processtopologyapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/profileapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/realtimeapiset.h \
 C:/mingw64/x86_64-w64-mingw32/include/securityappcontainer.h \
 C:/mingw64/x86_64-w64-mingw32/include/securitybaseapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/synchapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/sysinfoapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/systemtopologyapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/threadpoolapiset.h \
 C:/mingw64/x86_64-w64-mingw32/include/threadpoollegacyapiset.h \
 C:/mingw64/x86_64-w64-mingw32/include/utilapiset.h \
 C:/mingw64/x86_64-w64-mingw32/include/wow64apiset.h \
 C:/mingw64/x86_64-w64-mingw32/include/winerror.h \
 C:/mingw64/x86_64-w64-mingw32/include/fltwinerror.h \
 C:/mingw64/x86_64-w64-mingw32/include/timezoneapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/wingdi.h \
 C:/mingw64/x86_64-w64-mingw32/include/pshpack1.h \
 C:/mingw64/x86_64-w64-mingw32/include/winuser.h \
 C:/mingw64/x86_64-w64-mingw32/include/tvout.h \
 C:/mingw64/x86_64-w64-mingw32/include/winnls.h \
 C:/mingw64/x86_64-w64-mingw32/include/datetimeapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/stringapiset.h \
 C:/mingw64/x86_64-w64-mingw32/include/wincon.h \
 C:/mingw64/x86_64-w64-mingw32/include/wincontypes.h \
 C:/mingw64/x86_64-w64-mingw32/include/consoleapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/consoleapi2.h \
 C:/mingw64/x86_64-w64-mingw32/include/consoleapi3.h \
 C:/mingw64/x86_64-w64-mingw32/include/winver.h \
 C:/mingw64/x86_64-w64-mingw32/include/winreg.h \
 C:/mingw64/x86_64-w64-mingw32/include/reason.h \
 C:/mingw64/x86_64-w64-mingw32/include/winnetwk.h \
 C:/mingw64/x86_64-w64-mingw32/include/wnnc.h \
 C:/mingw64/x86_64-w64-mingw32/include/virtdisk.h \
 C:/mingw64/x86_64-w64-mingw32/include/cderr.h \
 C:/mingw64/x86_64-w64-mingw32/include/dde.h \
 C:/mingw64/x86_64-w64-mingw32/include/ddeml.h \
 C:/mingw64/x86_64-w64-mingw32/include/dlgs.h \
 C:/mingw64/x86_64-w64-mingw32/include/lzexpand.h \
 C:/mingw64/x86_64-w64-mingw32/include/mmsystem.h \
 C:/mingw64/x86_64-w64-mingw32/include/mmsyscom.h \
 C:/mingw64/x86_64-w64-mingw32/include/mciapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/mmiscapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/mmiscapi2.h \
 C:/mingw64/x86_64-w64-mingw32/include/playsoundapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/mmeapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/timeapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/joystickapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/nb30.h \
 C:/mingw64/x86_64-w64-mingw32/include/rpc.h \
 C:/mingw64/x86_64-w64-mingw32/include/rpcdce.h \
 C:/mingw64/x86_64-w64-mingw32/include/rpcdcep.h \
 C:/mingw64/x86_64-w64-mingw32/include/rpcnsi.h \
 C:/mingw64/x86_64-w64-mingw32/include/rpcnterr.h \
 C:/mingw64/x86_64-w64-mingw32/include/rpcasync.h \
 C:/mingw64/x86_64-w64-mingw32/include/shellapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/winperf.h \
 C:/mingw64/x86_64-w64-mingw32/include/winsock.h \
 C:/mingw64/x86_64-w64-mingw32/include/_timeval.h \
 C:/mingw64/x86_64-w64-mingw32/include/_bsd_types.h \
 C:/mingw64/x86_64-w64-mingw32/include/inaddr.h \
 C:/mingw64/x86_64-w64-mingw32/include/psdk_inc/_socket_types.h \
 C:/mingw64/x86_64-w64-mingw32/include/psdk_inc/_fd_types.h \
 C:/mingw64/x86_64-w64-mingw32/include/psdk_inc/_ip_types.h \
 C:/mingw64/x86_64-w64-mingw32/include/psdk_inc/_ip_mreq1.h \
 C:/mingw64/x86_64-w64-mingw32/include/psdk_inc/_wsadata.h \
 C:/mingw64/x86_64-w64-mingw32/include/psdk_inc/_xmitfile.h \
 C:/mingw64/x86_64-w64-mingw32/include/psdk_inc/_wsa_errnos.h \
 C:/mingw64/x86_64-w64-mingw32/include/wincrypt.h \
 C:/mingw64/x86_64-w64-mingw32/include/bcrypt.h \
 C:/mingw64/x86_64-w64-mingw32/include/ncrypt.h \
 C:/mingw64/x86_64-w64-mingw32/include/dpapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/winefs.h \
 C:/mingw64/x86_64-w64-mingw32/include/winscard.h \
 C:/mingw64/x86_64-w64-mingw32/include/wtypes.h \
 C:/mingw64/x86_64-w64-mingw32/include/rpcndr.h \
 C:/mingw64/x86_64-w64-mingw32/include/rpcnsip.h \
 C:/mingw64/x86_64-w64-mingw32/include/rpcsal.h \
 C:/mingw64/x86_64-w64-mingw32/include/ole2.h \
 C:/mingw64/x86_64-w64-mingw32/include/objbase.h \
 C:/mingw64/x86_64-w64-mingw32/include/combaseapi.h \
 C:/mingw64/x86_64-w64-mingw32/include/wtypesbase.h \
 C:/mingw64/x86_64-w64-mingw32/include/unknwnbase.h \
 C:/mingw64/x86_64-w64-mingw32/include/objidlbase.h \
 C:/mingw64/x86_64-w64-mingw32/include/cguid.h \
 C:/mingw64/x86_64-w64-mingw32/include/objidl.h \
 C:/mingw64/x86_64-w64-mingw32/include/unknwn.h \
 C:/mingw64/x86_64-w64-mingw32/include/urlmon.h \
 C:/mingw64/x86_64-w64-mingw32/include/oleidl.h \
 C:/mingw64/x86_64-w64-mingw32/include/servprov.h \
 C:/mingw64/x86_64-w64-mingw32/include/msxml.h \
 C:/mingw64/x86_64-w64-mingw32/include/oaidl.h \
 C:/mingw64/x86_64-w64-mingw32/include/propidl.h \
 C:/mingw64/x86_64-w64-mingw32/include/oleauto.h \
 C:/mingw64/x86_64-w64-mingw32/include/winioctl.h \
 C:/mingw64/x86_64-w64-mingw32/include/winsmcrd.h \
 C:/mingw64/x86_64-w64-mingw32/include/winspool.h \
 C:/mingw64/x86_64-w64-mingw32/include/prsht.h \
 C:/mingw64/x86_64-w64-mingw32/include/commdlg.h \
 C:/mingw64/x86_64-w64-mingw32/include/stralign.h \
 C:/mingw64/x86_64-w64-mingw32/include/sec_api/stralign_s.h \
 C:/mingw64/x86_64-w64-mingw32/include/winsvc.h \
 C:/mingw64/x86_64-w64-mingw32/include/mcx.h \
 C:/mingw64/x86_64-w64-mingw32/include/imm.h \
 C:/mingw64/include/c++/15.2.0/iostream \
 C:/mingw64/include/c++/15.2.0/ostream \
 C:/mingw64/include/c++/15.2.0/bits/ostream.h \
 C:/mingw64/include/c++/15.2.0/ios \
 C:/mingw64/include/c++/15.2.0/exception \
 C:/mingw64/include/c++/15.2.0/bits/exception_ptr.h \
 C:/mingw64/include/c++/15.2.0/bits/cxxabi_init_exception.h \
 C:/mingw64/include/c++/15.2.0/bits/nested_exception.h \
 C:/mingw64/include/c++/15.2.0/bits/ios_base.h \
 C:/mingw64/include/c++/15.2.0/ext/atomicity.h \
 C:/mingw64/include/c++/15.2.0/x86_64-w64-mingw32/bits/gthr.h \
 C:/mingw64/include/c++/15.2.0/x86_64-w64-mingw32/bits/gthr-default.h \
 C:/mingw64/x86_64-w64-mingw32/include/pthread.h \
 C:/mingw64/x86_64-w64-mingw32/include/sys/types.h \
 C:/mingw64/x86_64-w64-mingw32/include/process.h \
 C:/mingw64/x86_64-w64-mingw32/include/corecrt_startup.h \
 C:/mingw64/x86_64-w64-mingw32/include/signal.h \
 C:/mingw64/x86_64-w64-mingw32/include/pthread_signal.h \
 C:/mingw64/x86_64-w64-mingw32/include/time.h \
 C:/mingw64/x86_64-w64-mingw32/include/sys/timeb.h \
 C:/mingw64/x86_64-w64-mingw32/include/sec_api/sys/timeb_s.h \
 C:/mingw64/x86_64-w64-mingw32/include/pthread_time.h \
 C:/mingw64/x86_64-w64-mingw32/include/pthread_compat.h \
 C:/mingw64/x86_64-w64-mingw32/include/sched.h \
 C:/mingw64/x86_64-w64-mingw32/include/pthread_unistd.h \
 C:/mingw64/include/c++/15.2.0/x86_64-w64-mingw32/bits/atomic_word.h \
 C:/mingw64/include/c++/15.2.0/bits/locale_classes.h \
 C:/mingw64/include/c++/15.2.0/bits/locale_classes.tcc \
 C:/mingw64/include/c++/15.2.0/system_error \
 C:/mingw64/include/c++/15.2.0/x86_64-w64-mingw32/bits/error_constants.h \
 C:/mingw64/include/c++/15.2.0/stdexcept \
 C:/mingw64/include/c++/15.2.0/streambuf \
 C:/mingw64/include/c++/15.2.0/bits/streambuf.tcc \
 C:/mingw64/include/c++/15.2.0/bits/basic_ios.h \
 C:/mingw64/include/c++/15.2.0/bits/locale_facets.h \
 C:/mingw64/include/c++/15.2.0/cwctype \
 C:/mingw64/x86_64-w64-mingw32/include/wctype.h \
 C:/mingw64/include/c++/15.2.0/x86_64-w64-mingw32/bits/ctype_base.h \
 C:/mingw64/include/c++/15.2.0/bits/streambuf_iterator.h \
 C:/mingw64/include/c++/15.2.0/x86_64-w64-mingw32/bits/ctype_inline.h \
 C:/mingw64/include/c++/15.2.0/bits/locale_facets.tcc \
 C:/mingw64/include/c++/15.2.0/bits/basic_ios.tcc \
 C:/mingw64/include/c++/15.2.0/bits/ostream.tcc \
 C:/mingw64/include/c++/15.2.0/istream \
 C:/mingw64/include/c++/15.2.0/bits/istream.tcc \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/gtc/type_ptr.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/gtc/quaternion.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_relational.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_relational.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_float.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/quaternion_common.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/quaternion_geometric.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/quaternion_geometric.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/quaternion_common.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/quaternion_float.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_quat.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/quaternion_relational.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/quaternion_relational.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/type_quat.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/quaternion_float_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/quaternion_double.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/quaternion_double_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/quaternion_trigonometric.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/quaternion_trigonometric.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/quaternion_transform.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/quaternion_transform.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/gtc/quaternion.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/gtc/epsilon.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/detail/setup.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/gtc/epsilon.inl \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/gtc/vec1.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_bool1.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_bool1_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_float1.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_float1_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_double1.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_double1_precision.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_int1.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_int1_sized.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_uint1.hpp \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/ext/vector_uint1_sized.hpp \
 C:/mingw64/include/c++/15.2.0/cstring \
 E:/SOOBSHESTVA/Game_Engine/VERSION\ 3/3/include/glm/gtc/type_ptr.inl
